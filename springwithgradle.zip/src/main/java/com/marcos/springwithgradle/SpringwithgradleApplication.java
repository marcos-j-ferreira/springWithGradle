package com.marcos.springwithgradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwithgradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwithgradleApplication.class, args);
	}

}
